
#!/bin/sh
echo  -en "stop redis..."
kill -9 `cat $(pwd)/bin/redis.pid`
echo  -en "success\n"

