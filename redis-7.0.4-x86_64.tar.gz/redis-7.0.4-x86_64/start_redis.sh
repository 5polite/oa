
#!/bin/sh

redisdir=$(pwd)

echo  -en "start redis..."
if [ -d ${redisdir}/bin ];then
    
    cd ${redisdir}/bin

    cache_list=$(ls ${redisdir}/bin/redis*.conf)
    for cache_conf in ${cache_list[@]}
    do
	#sed -i "s;^\s*logfile\s*\"*/opt/redis_test/redis/logs/\([^\"]*\)\"*;logfile ${redisdir}/logs/\1;g" ${cache_conf}
	#sed -i "s;^\s*pidfile\s*/opt/redis_test/redis/bin/\(.*\);pidfile ${redisdir}/bin/\1;g" ${cache_conf}
	${redisdir}/bin/redis-server ${cache_conf}
    done

    echo  -en "success\n"
fi

